## Welcome to Github

The map can be viewed [here](https://githubschool.github.io/open-enrollment-classes-introduction-to-github/).
